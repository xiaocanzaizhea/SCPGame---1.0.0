package xyz.xiaocan.teams.roletypes;

public interface RoleType {
    public String getId();
}
