package xyz.xiaocan.teams.roletypes;

public enum RoleCategory {

    CHAOS,
    MTF,
    SCP,             // SCP怪物
    SPEC,       // 观察者
}
