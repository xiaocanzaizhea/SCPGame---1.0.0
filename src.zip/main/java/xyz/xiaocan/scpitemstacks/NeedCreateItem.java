package xyz.xiaocan.scpitemstacks;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public interface NeedCreateItem {
    public ItemStack createItem();
}
