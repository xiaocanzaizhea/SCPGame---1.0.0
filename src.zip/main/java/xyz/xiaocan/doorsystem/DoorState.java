package xyz.xiaocan.doorsystem;

public enum DoorState {
    CLOSED,
    OPEN,
    CLOSING,
    OPENING
}
