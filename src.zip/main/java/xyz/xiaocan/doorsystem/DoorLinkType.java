package xyz.xiaocan.doorsystem;

public enum DoorLinkType {
    BOTH,
    EITHER,
    NONE;
}
